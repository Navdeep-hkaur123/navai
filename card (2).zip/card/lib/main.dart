import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:math';

void main() {
  runApp(PokemonApp());
}

class PokemonApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pokémon TCG',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.blueGrey.shade800,
          titleTextStyle: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        textTheme: TextTheme(
          bodyLarge: TextStyle(fontSize: 18, color: Colors.grey.shade800),
          bodyMedium: TextStyle(fontSize: 16, color: Colors.grey.shade600),
        ),
      ),
      home: SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => PokemonBattleScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/background.jpg', // Your background image
            fit: BoxFit.cover,
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset(
                  'assets/logo.jpg', // Your logo image
                  width: 150,
                ),
                SizedBox(height: 20),
                Text(
                  'Pokémon TCG',
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class PokemonBattleScreen extends StatefulWidget {
  @override
  _PokemonBattleScreenState createState() => _PokemonBattleScreenState();
}

class _PokemonBattleScreenState extends State<PokemonBattleScreen> {
  Map<String, dynamic>? card1;
  Map<String, dynamic>? card2;
  String? winner;
  bool isLoading = false;

  Future<void> fetchRandomCards() async {
    const String apiUrl = 'https://api.pokemontcg.io/v2/cards';
    const String apiKey = '9d276280-a93e-467a-a6eb-6be1285a39fd';

    setState(() {
      isLoading = true;
      winner = null;
    });

    try {
      final randomPage = Random().nextInt(50) + 1;
      final response = await http.get(
        Uri.parse('$apiUrl?page=$randomPage&pageSize=2'),
        headers: {'X-Api-Key': apiKey},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final cards = data['data'];
        if (cards.length >= 2) {
          setState(() {
            card1 = cards[0];
            card2 = cards[1];
            isLoading = false;
            determineWinner();
          });
        }
      } else {
        throw Exception('Failed to load cards');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error fetching cards: $e')));
    }
  }

  void determineWinner() {
    if (card1 != null && card2 != null) {
      final String? hp1String = card1!['hp'];
      final String? hp2String = card2!['hp'];

      final int hp1 = hp1String != null ? int.tryParse(hp1String) ?? 0 : 0;
      final int hp2 = hp2String != null ? int.tryParse(hp2String) ?? 0 : 0;

      if (hp1 > hp2) {
        winner = card1!['name'] ?? 'Unknown';
      } else if (hp2 > hp1) {
        winner = card2!['name'] ?? 'Unknown';
      } else {
        winner = 'It\'s a tie!';
      }
    } else {
      winner = 'Cards are not loaded yet!';
    }
  }

  @override
  void initState() {
    super.initState();
    fetchRandomCards();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pokémon Battle'),
        backgroundColor: Colors.black87, // Dark background for app bar
      ),
      backgroundColor: const Color.fromARGB(221, 11, 9, 9), // Dark background color for the battle screen
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (card1 != null && card2 != null) ...[
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: GridView.count(
                        shrinkWrap: true,
                        crossAxisCount: 2,
                        mainAxisSpacing: 20,
                        crossAxisSpacing: 20,
                        children: [
                          CardDisplay(card: card1!),
                          CardDisplay(card: card2!),
                        ],
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      'VS',
                      style: TextStyle(
                        fontSize: 40,
                        fontWeight: FontWeight.bold,
                        color: Colors.orangeAccent,
                      ),
                    ),
                  ],
                  SizedBox(height: 30),
                  if (winner != null)
                    Text(
                      'Winner: $winner',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: winner == 'It\'s a tie!' ? Colors.grey : Colors.green,
                      ),
                    ),
                  SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: fetchRandomCards,
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                      backgroundColor: Colors.orangeAccent,
                    ),
                    child: Text('Battle Again', style: TextStyle(fontSize: 18)),
                  ),
                ],
              ),
            ),
    );
  }
}

class CardDisplay extends StatelessWidget {
  final Map<String, dynamic> card;

  CardDisplay({required this.card});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 15, // Increased shadow for better depth effect
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      color: const Color.fromARGB(66, 139, 82, 82), // Dark background color for the cards
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.network(
              card['images']['large'] ?? '',
              height: 250,
              width: 200,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => Icon(Icons.error, size: 100),
            ),
            SizedBox(height: 15),
            Text(
              card['name'] ?? 'Unknown',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 5),
            Text(
              'HP: ${card['hp'] ?? 'Unknown'}',
              style: TextStyle(fontSize: 16, color: Colors.white70),
            ),
          ],
        ),
      ),
    );
  }
}
