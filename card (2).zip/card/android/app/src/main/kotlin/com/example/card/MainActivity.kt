package com.example.card

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
